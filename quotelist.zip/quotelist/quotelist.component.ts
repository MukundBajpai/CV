import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../navbar/navbar.component';

@Component({
  selector: 'app-quotelist',
  imports: [CommonModule, FormsModule, NavbarComponent],
  templateUrl: './quotelist.component.html',
  styleUrls: ['./quotelist.component.css']
})
export class QuotelistComponent {
  statusList: string[] = ['In Review', 'Approved', 'Rejected'];
  selectedStatus: string = '';
  selectedDateRange: string = '';
  searchQuery: string = '';

  quotes = [
    { id: 'QT-2025-001', customerName: 'Robert Smith', submissionDate: '2025-01-15', premium: 2500, status: 'In Review' },
    { id: 'QT-2025-002', customerName: 'Alice Johnson', submissionDate: '2025-02-01', premium: 3200, status: 'Approved' },
    { id: 'QT-2025-003', customerName: 'John Doe', submissionDate: '2025-03-10', premium: 1800, status: 'Rejected' }
  ];

  currentPage = 1;
  itemsPerPage = 5;

  get filteredQuotes() {
    return this.quotes
      .filter(quote => (this.selectedStatus ? quote.status === this.selectedStatus : true))
      .filter(quote => (this.searchQuery ? quote.customerName.toLowerCase().includes(this.searchQuery.toLowerCase()) : true));
  }

  get paginatedQuotes() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.filteredQuotes.slice(startIndex, endIndex);
  }

  get totalPages() {
    return Math.ceil(this.filteredQuotes.length / this.itemsPerPage);
  }

  prevPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  openNewQuoteForm() {
    alert('New Quote Form Coming Soon!');
  }

  viewQuote(quote: any) {
    alert(`Viewing details for ${quote.customerName}`);
  }

  editQuote(quote: any) {
    alert(`Editing ${quote.customerName}`);
  }

  deleteQuote(quote: any) {
    this.quotes = this.quotes.filter(q => q.id !== quote.id);
  }
}


