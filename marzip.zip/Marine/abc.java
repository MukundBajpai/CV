import java.util.Scanner;

class Transaction{
    int transactionId;
    double amount;
    String extraInfo,type;

    public Transaction(int id,double amt,String info,String t)
    {
        transactionId=id;
        amount=amt;
        extraInfo=info;
        type=t;
    }

    public String getTransactionInfo()
    {
        return type + "Transaction:\nTransaction ID: " + transactionId + "\nAmount: $" + String.format("%.2f", amount) + "\n" + extraInfo;
    }


}

public class Main{
    public static void main(String[] args)
    {
        Scanner sc= new Scanner(System.in);
        int id = sc.nextInt();
        double amt=sc.nextDouble();
        sc.nextLine
    }
}