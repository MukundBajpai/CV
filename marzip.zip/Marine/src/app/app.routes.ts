import { Routes } from '@angular/router';
import { DashboardComponent } from '../Component/dashboard/dashboard.component';
import { LoginComponent } from '../Component/login/login.component';
import { HomepageComponent } from '../Component/homepage/homepage.component';
import { QuoteformComponent } from '../Component/quoteform/quoteform.component';


export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomepageComponent }
  ,
  { path: 'quoteform', component: QuoteformComponent}
];
