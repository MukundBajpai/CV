import { Component } from '@angular/core';
import { NavigationEnd, Router, RouterModule, RouterOutlet } from '@angular/router';
import { NavbarComponent } from '../Component/navbar/navbar.component';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from "../Component/sidebar/sidebar.component";
import { DashboardComponent } from '../Component/dashboard/dashboard.component';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, NavbarComponent, CommonModule, RouterModule, SidebarComponent, DashboardComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Marine';
  showNavbar: boolean = true;

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.showNavbar = !['/login', '/signup'].includes(event.urlAfterRedirects);
      }
    });
  
  }
  }
