import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-quoteform',
  templateUrl: './quoteform.component.html',
  imports: [CommonModule, RouterModule,ReactiveFormsModule,],
  styleUrls: ['./quoteform.component.css'],
})
export class QuoteformComponent {
  quoteForm: FormGroup;
  premium: number = 0; // Initial premium value

  constructor(private fb: FormBuilder) {
    this.quoteForm = this.fb.group({
      name: ['', Validators.required],
      address: ['', Validators.required],
      contactNumber: [
        '',
        [Validators.required, Validators.pattern('^[0-9]{10}$')],
      ],
      vehicleType: ['', Validators.required],
      vehicleValue: [0, [Validators.required, Validators.min(1000)]],
      additionalCoverage: [false],
    });

    // Watch form changes and update premium dynamically
    this.quoteForm.valueChanges.subscribe((values) => {
      this.calculatePremium(values);
    });
  }

  // Calculate premium dynamically based on user input
  calculatePremium(values: any) {
    let basePremium = values.vehicleValue * 0.02; // 2% of vehicle value
    if (values.additionalCoverage) {
      basePremium += 200; // Add-on premium for additional coverage
    }
    this.premium = basePremium;
  }

  // Submit the form
  submitQuote() {
    if (this.quoteForm.valid) {
      console.log('Quote submitted:', this.quoteForm.value);
      alert('Quote created successfully! 🎉');
    } else {
      alert('Please fill in all required fields! ❗');
    }
  }
}
