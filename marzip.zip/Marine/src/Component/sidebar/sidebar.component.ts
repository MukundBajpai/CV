import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'] // Fixed to 'styleUrls' for an array, which is the correct syntax
})
export class SidebarComponent implements OnInit {
  
  isLoggedIn = false; // Example property, replace with actual logic
  userName = 'John Doe'; // Example property, replace with actual logic
  showSidebar: boolean = true; // Track sidebar visibility

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Subscribe to router events to control sidebar visibility
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.showSidebar = !['/login', '/signup'].includes(event.urlAfterRedirects);
      }
    });
  }

  navigateToHome(): void {
    this.router.navigate(['/home']); // Navigate to the home route
  }

  // toggleSidebar(): void {
  //   const sidebar = document.querySelector('.sub-navbar');
  //   if (sidebar) {
  //     sidebar.classList.toggle('open'); // Toggle the 'open' class on the sidebar
  //   }
  }

