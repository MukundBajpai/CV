import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage',
  imports: [],
  templateUrl: './homepage.component.html',
  styleUrl: './homepage.component.css'
})
export class HomepageComponent implements OnInit {
  floodInsuranceDetails: any[] = [];

  constructor() { }

  ngOnInit(): void {
    this.floodInsuranceDetails = [
      {
        title: 'Flood Risk Assessments',
        description: 'Understand the likelihood and potential damage of flooding in your area with our detailed flood risk assessments.',
        image: 'assets/flood-risk.jpg'
      },
      {
        title: 'Community Protections',
        description: 'Benefit from community protections such as dunes, wetlands, seawalls, and pumps to reduce flood risk.',
        image: 'assets/community-protection.jpg'
      },
      {
        title: 'Flood Resilience',
        description: 'Enhance your resilience to flood events with timely warnings, temporary barriers, and effective evacuation plans.',
        image: 'assets/flood-resilience.jpg'
      }
    ];
  }
}
