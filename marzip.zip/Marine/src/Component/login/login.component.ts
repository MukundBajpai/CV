// import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
// import { routes } from '../../app/app.routes';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  constructor(private router:Router){}
  email: string = '';
  password: string = '';
  remember: boolean = false;

  onSubmit() {
    // Implement your login logic here
    console.log('Email:', this.email);
    console.log('Password:', this.password);
    console.log('Remember me:', this.remember);
  }
  guestLogin() {
    // Implement guest login logic here
    console.log('Guest login');
    this.router.navigate(['/home']);
  }

}
