import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-navbar',
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  isLoggedIn = false; // Example property, replace with actual logic
  userName = 'John Doe'; // Example property, replace with actual logic

  constructor(private router: Router) {}

  // Navigate to home
  navigateToHome() {
    this.router.navigate(['/home']);
  }
}
